-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 08:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodies`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
USE foodies;
CREATE TABLE `admin` (
  `Admin_id` int(11) NOT NULL,
  `Admin_name` varchar(20) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_id`, `Admin_name`, `Password`) VALUES
(1, 'Dolly', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'madhuri', '21232f297a57a5a743894a0e4a801fc3'),
(3, 'admin1', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `Bill_id` int(11) NOT NULL,
  `Bill_date` date NOT NULL,
  `Bill_amount` int(11) NOT NULL,
  `Payment_id` int(11) NOT NULL,
  `DeliveryPartner_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`Bill_id`, `Bill_date`, `Bill_amount`, `Payment_id`, `DeliveryPartner_name`) VALUES
(1, '2023-09-17', 160, 1, ''),
(2, '2023-09-17', 60, 2, 'Partner1'),
(3, '2023-09-17', 300, 3, 'Partner1'),
(4, '2023-09-19', 220, 4, 'Partner1'),
(5, '2023-09-20', 35, 5, 'Partner1');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Order_id` int(11) NOT NULL,
  `Food_id` int(20) NOT NULL,
  `Food_name` varchar(30) NOT NULL,
  `Price` int(20) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `User_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_id` int(11) NOT NULL,
  `Category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_id`, `Category_name`) VALUES
(1, 'Breakfast'),
(2, 'Lunch'),
(3, 'Dinner');

-- --------------------------------------------------------

--
-- Table structure for table `deliverypartner`
--

CREATE TABLE `deliverypartner` (
  `DeliveryPartner_id` int(11) NOT NULL,
  `DeliveryPartner_name` varchar(20) NOT NULL,
  `Contact` int(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deliverypartner`
--

INSERT INTO `deliverypartner` (`DeliveryPartner_id`, `DeliveryPartner_name`, `Contact`, `Email`, `Order_id`) VALUES
(1, 'Partner1', 2147483647, 'partner1@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback_id` int(11) NOT NULL,
  `User_name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Feedback_message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback_id`, `User_name`, `Email`, `Feedback_message`) VALUES
(1, 'Dolly', 'dolly@gmail.com', 'Nice services and delicious food'),
(2, 'Dolly', 'dolly@gmail.com', 'Testy food'),
(3, 'Aastha', 'aastha@gmail.com', 'Nice Services\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `Food_id` int(11) NOT NULL,
  `Food_name` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Food_image` varchar(50) NOT NULL,
  `Menu_name` varchar(20) NOT NULL,
  `Category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`Food_id`, `Food_name`, `Price`, `Food_image`, `Menu_name`, `Category_name`) VALUES
(1, 'Thepla', 30, 'thepla.png', 'Gujarati', 'Breakfast'),
(2, 'Khandvi', 50, 'khandvi.png', 'Gujarati', 'Breakfast'),
(3, 'Fafda-Jalebi', 100, 'fafda.png', 'Gujarati', 'Breakfast'),
(4, 'Patra', 50, 'patra.png', 'Gujarati', 'Breakfast'),
(5, 'Idli-sambhar', 30, 'Product-3.png', 'Southindian', 'Breakfast'),
(6, 'Plaindosha', 80, 'Product-2.png', 'Southindian', 'Breakfast'),
(7, 'Menduvada', 60, 'Product-1.png', 'Southindian', 'Breakfast'),
(8, 'Utpama', 40, 'Product-4.png', 'Southindian', 'Breakfast'),
(9, 'Green Sandwich', 40, 'product1.png', 'Sandwich', 'Breakfast'),
(10, 'Panini Sandwich', 80, 'product3.png', 'Sandwich', 'Breakfast'),
(11, 'CheesGrill Sandwich', 100, 'sandwich.png', 'Sandwich', 'Breakfast'),
(12, 'Masala toast', 35, 'aloo sandwich.jpg', 'Sandwich', 'Breakfast'),
(13, 'Full-thali', 160, 'fullthali.jpeg', 'Kathiyawadi', 'Lunch'),
(14, 'Chapdiundhiyu', 100, 'chapdi undhiyu.png', 'Kathiyawadi', 'Lunch'),
(15, 'Vagharelo-rotlo', 100, 'Vaghrelorotlo.png', 'Kathiyawadi', 'Lunch'),
(16, 'Khichdi', 60, 'khichdi.png', 'Kathiyawadi', 'Lunch'),
(17, 'Full-Dish', 200, 'Full dish.png', 'Gujarati', 'Lunch'),
(18, 'Undhiyu', 90, 'undhiyu.png', 'Gujarati', 'Lunch'),
(19, 'Chapati', 20, 'chapati.png', 'Gujarati', 'Lunch'),
(20, 'Dal-bhat', 60, 'daalbhat.png', 'Gujarati', 'Lunch'),
(21, 'Cholebhature', 130, 'cholebhature.png', 'Punjabi', 'Dinner'),
(22, 'Garlic naan', 50, 'Garlic-naan.jpg', 'Punjabi', 'Dinner'),
(23, 'Paneertika sabji', 100, 'panirtika.png', 'Punjabi', 'Dinner'),
(24, 'Dalfry-rice', 70, 'dalfry-rice.jpg', 'Punjabi', 'Dinner'),
(25, 'Manchurian', 80, 'vegetable-manchurian-dry.jpg', 'Chinese', 'Dinner'),
(26, 'Noodles', 70, '4url.jpg', 'Chinese', 'Dinner'),
(27, 'Friedrice', 80, 'friedrice.PNG', 'Chinese', 'Dinner'),
(28, 'Vegitable Soup', 100, 'Vegetable-Soup-.jpg', 'Chinese', 'Dinner'),
(29, 'Paavbhaji', 80, 'paav bhaji.png', 'Fastfood', 'Dinner'),
(30, 'Pizza', 110, 'cheespizza.png', 'Fastfood', 'Dinner'),
(31, 'Burger', 100, 'Burger.png', 'Fastfood', 'Dinner'),
(32, 'Veg. Momos', 80, 'momos.png', 'Fastfood', 'Dinner'),
(33, 'Gulabjamun', 30, 'gulabjambu.jpg', 'Sweet', 'Lunch'),
(34, 'Jalebi', 40, 'jabeli.jpg', 'Sweet', 'Lunch');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `Menu_id` int(11) NOT NULL,
  `Menu_name` varchar(20) NOT NULL,
  `Menu_image` varchar(100) NOT NULL,
  `Category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`Menu_id`, `Menu_name`, `Menu_image`, `Category_name`) VALUES
(1, 'Southindian', 'southindian.png', 'Breakfast'),
(2, 'Gujarati', 'gujaratibreakfast.png', 'Breakfast'),
(3, 'Sandwich', 'product2.png', 'Breakfast'),
(4, 'Kathiyawadi', 'kathiyawadi.png', 'Lunch'),
(5, 'Gujarati', 'lunch.png', 'Lunch'),
(6, 'Punjabi', 'punjabi2.jpg', 'Dinner'),
(7, 'Chinese', 'chinese.jpg', 'Dinner'),
(8, 'Fastfood', 'BGCombo.jpg', 'Dinner'),
(9, 'Sweet', 'sweets.jpg', 'Lunch');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_id` int(11) NOT NULL,
  `Payment_date` date NOT NULL,
  `Food_name` varchar(30) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `Price` int(11) NOT NULL,
  `Total_price` int(11) NOT NULL,
  `User_name` varchar(20) NOT NULL,
  `Order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_id`, `Payment_date`, `Food_name`, `Quantity`, `Price`, `Total_price`, `User_name`, `Order_id`) VALUES
(2, '2023-09-17', 'Khichdi', 1, 60, 60, 'Dolly', 2),
(3, '2023-09-17', 'Burger', 3, 100, 300, 'Aastha', 3),
(4, '2023-09-19', 'Pizza', 2, 110, 220, 'User', 4),
(5, '2023-09-20', 'Masala toast', 1, 35, 35, 'Aastha', 5),
(6, '2023-09-20', '', 0, 0, 0, 'Aastha', 5);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `Restaurant_id` int(11) NOT NULL,
  `Restaurant_name` varchar(20) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Contact` bigint(100) NOT NULL,
  `Restaurant_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`Restaurant_id`, `Restaurant_name`, `Address`, `Contact`, `Restaurant_image`) VALUES
(1, 'The Grand Murlidhar', 'Jamnagar - Rajkot Hwy, Naranka,Rajkot', 8511156783, 'tgm1.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_id` int(11) NOT NULL,
  `First_name` varchar(30) NOT NULL,
  `Last_name` varchar(30) NOT NULL,
  `User_name` varchar(20) NOT NULL,
  `Contact` bigint(20) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_id`, `First_name`, `Last_name`, `User_name`, `Contact`, `Address`, `Email`, `Password`) VALUES
(1, 'Dolly', 'Trivedi', 'Dolly', 2147483647, 'dolly@gmail.com', 'Rajkot', 'e69abc9adfd625f274f9fce5675a2a12'),
(2, 'Aastha', 'Patel', 'Aastha', 9989076665, 'aastha@gmaill.com', 'Ahemdabad', '5b4faebd9e04c81bd935e19a03a3de66'),
(3, 'User', 'User', 'User', 34354354354, 'user1@gmail.com', 'Surat', '6ad14ba9986e3615423dfca256d04e3f');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`Bill_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Order_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `deliverypartner`
--
ALTER TABLE `deliverypartner`
  ADD PRIMARY KEY (`DeliveryPartner_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Feedback_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`Food_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`Menu_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`Restaurant_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `Bill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `deliverypartner`
--
ALTER TABLE `deliverypartner`
  MODIFY `DeliveryPartner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `Food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `Menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `Restaurant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

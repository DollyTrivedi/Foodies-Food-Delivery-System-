<?php
include ("connection.php");
include ("header.php");

	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
	if (isset($_POST['Save'])) 
	{
	$mn=$_POST['menuname'];
	$cnm=$_POST['categoryname'];
	
	
	$filename = $_FILES["menuimg"]["name"];
    $tempname = $_FILES["menuimg"]["tmp_name"];
    $folder = "../images/" . $filename;
	
	if(empty($mn) && empty($filename))
		{
			header("location: add_menu.php");
		}
		else{
		
    // Now let's move the uploaded image into the folder: image
	mysqli_query($conn,"insert into menu(Menu_name,Menu_image,Category_name) values('$mn','$filename','$cnm')");
	
	if (move_uploaded_file($tempname, $folder)) 
	{
        echo "<h3>  Image uploaded successfully!</h3>";
    } else 
        echo "<h3>  Failed to upload image!</h3>";
    
		echo "<script>window.location='menu.php';</script>";
	}
	}

?>
<!DOCTYPE html>
<html>



<body class="sub_page" background="images\bg4.png">
 
 <style>
   a{
	 color: white; 
 }
 
 .abc{
	 text-align: center;
	 font-size: 25px; 
	 background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
 }
  .table2{
	 text-align: left
	 font-size: 18px; 
	 
 }
 
  .child1{
	
	 display: inline-block;
	 vertical-align: middle;
	 width: 18.55%;
	 height: 80%;
	 position: absolute;
	background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
   font-family: "Roboto", sans-serif;
 }
 .child2{
	 display: inline-block;
	 vertical-align: middle;
	 width: 74%;
	 margin-left: 20%;
 }
 .delete{
	 color: blue;
 }
 .add{
	 font-size: 23px;
	  background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
	 
	 
 }
 .footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: relative;
	width: 100%;
	top: 17px;
	bottom: 0;
	margin: 0px;
	
}
 </style>
<div class='parent' width=100%>	
 <div class='child1'> 
   <table width=100%  height=80% bgcolor=#0077FFF class=abc>
 <tr>
  <td>
  <a href="home.php">Home</a>
  </td>
  </tr>
  
   <tr>
  <td>
  <a href="userdetails.php">Userdetails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="restaurents.php">Resturants</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="category.php">Category<a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="menu.php">Menu</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="products.php">Products Deatails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="order.php">Oreder Details</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="feedback.php">Feedback Detils</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="deliverypartner.php">Delivery Partner
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="logout.php">Logout</a>
  </td>
  </tr>
  </table>
  </div>
  
  <div class='child2'>
 <?php
 $cat=mysqli_query($conn,"select * from category");
 
 ?>
  <form method="post" enctype="multipart/form-data" >
  <table align=center width=80% style="margin-bottom:210px" class=table2 >
 
	<tr>
	<td colspan=2>
	<h2><b>Add new Menu</b></h2><br>
	</td>
  </tr>
	<tr>
		<td style="font-size: 23px">
		<label>Menu name </label>
		</td>
		<td style="font-size: 23px">
		<input type=text name="menuname" required />
		</td>
	</tr>
	
	<tr>
		<td style="font-size: 23px">
		<label>Category </label>
		</td>
		<td style="font-size: 23px">
		
		<select name="categoryname" required />
		
		<?php 
		while($cat1=mysqli_fetch_array($cat)){
		?>
			<option><?php echo $cat1[1];?></option>
		<?php }?>
		</select>
	
		</td>
	</tr>
		
	<tr>
		<td style="font-size: 23px">
		<label>Menu Image </label>
		</td>
		<td style="font-size:23px">
		
		<input type="file" name="menuimg" required />
		
		</td>
	</tr>

	<tr>
		<td colspan=2>
	<br><input type="submit"  name="Save" value="Save"class=add>
		</td>
	</tr>
	
  </table>
  </form><br>
  

  </div>
  
</div>
 
  
<?php
	}
	
	//include("myfooter.php");
	
?>
<div class=footer style="border: 2px solid">
<center>

 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 
 </center>
</div>
 </body>
</html>
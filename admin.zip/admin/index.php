<?php
	include("header.php");
	include("connection.php");
	if(isset($_POST['login']))
	{
	$un = $_POST['usernm'];
	$pn = md5($_POST['pass']);
	$rs = mysqli_query($conn,"select * from  admin where Admin_name='".$un."' and Password='".$pn."'");
	$cnt=mysqli_fetch_array($rs);
	if($cnt >= 1)
	{
		$_SESSION['sid']=$cnt[0];
		header("Location:home.php");
	}
	else?>
		<script>
		alert("Incorrect username or password");
		</script><?php
	}
?>




<!DOCTYPE html>
<html>
<body>
	<!-- Login Form -->
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
	width:500px;
	
  padding: 16px;
  background-color: skyblue;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: orange;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: skyblue;
  text-align: center;
}
</style>

<form method="post">
  <div class="container">
    <h3 align=center>Login</h3>
   
    <hr>
     <label for="psw"><b>User  Name</b></label>
    <input type="text" placeholder="First Name" name="usernm" id="firstname" required />

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" id="psw" required />
	
    <input type="submit"  name="login" value="Login" class="registerbtn"></button>

  </div>
  
  <div class="container signin">
    <p>Forgot Password? <a href="reset.php">Reset</a></p>
	
  </div>
</form><br>
  <!--  End Login Form -->
  
 <?php
	include("myfooter.php");
?>
 </body>
</html>
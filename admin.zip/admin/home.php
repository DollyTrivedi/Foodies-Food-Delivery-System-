<?php

include ("connection.php");
include ("header.php");
include("admincss.php");

	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <?php ?>
</head>

<body>      
           
			<div class="row tm-mb-90 tm-gallery">
        	<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
              <a href="userdetails.php"><div class="tm-bg-gray tm-video-details" style="margin-left:175px;width:350px;height:150px; background: #ff00ff" >
              <br>
              <font size=6 color=white>
              Visitors
              <font size=7 color=white>
             <div style="float:right">
                <?php
              
                $sql="select * from user";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowcount=mysqli_num_rows($result);
                }
                echo"$rowcount";

                ?>
                </div>
                </font>
                </font>               
              </div></a>
                
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <a href="restaurents.php"><div class="tm-bg-gray tm-video-details" style=
				"margin-left:175px;width:350px;height:150px; background: #D32D41">
                <br>
              <font size=6 color=white>
              Restaurants
              <font size=7 color=white>
             <div style="float:right">
                <?php
               
                $sql="select * from restaurant";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowacount=mysqli_num_rows($result);
                }
                echo"$rowacount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
           
            
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <a href="category.php"><div class="tm-bg-gray tm-video-details" style="margin-left:175px;width:350px;height:150px; background: #6AB187">
                <br>
              <font size=6 color=white>
              Category
              <font size=7 color=white>
             <div style="float:right">
                <?php
                
                $sql="select * from category";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowbcount=mysqli_num_rows($result);
                }
                echo"$rowbcount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
			
            </div>
            <div class="row tm-mb-90 tm-gallery">
        	<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
              <a href="menu.php"><div class="tm-bg-gray tm-video-details" style="margin-left:175px;width:350px;height:150px; background: #1C4E80">
              <br>
              <font size=6 color=white>
              Menu
              <font size=7 color=white>
             <div style="float:right">
                <?php
                
                $sql="select * from menu";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowccount=mysqli_num_rows($result);
                }
                echo"$rowccount";

                ?>
                </div>
                </font>
                </font>
              </div></a>
                
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <a href="products.php"><div class="tm-bg-gray tm-video-details" style="margin-left:175px;width:350px;height:150px; background: #E0B50F ">
                <br>
				 <font size=6 color=white>
                Products
				  <font size=7 color=white>
				  <div style="float:right">
				   <?php
              
                $sql="select * from food";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowecount=mysqli_num_rows($result);
                }
                echo"$rowecount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
           
            
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <a href="order.php"><div class="tm-bg-gray tm-video-details" style="margin-left:175px;width:350px;height:150px; background: #EA6A47">
                <br>
              <font size=6 color=white>
              Orders
              <font size=7 color=white>
             <div style="float:right">
                <?php
              
                $sql="select * from payment";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowecount=mysqli_num_rows($result);
                }
                echo"$rowecount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
            </div>
			
			<div class="row tm-mb-90 tm-gallery">
        	
			<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5" style="margin-left:370px;width:380px;height:150px;">
                <a href="feedback.php"><div class="tm-bg-gray tm-video-details"style="background: #17BEBB ">
                <br>
				 <font size=6 color=white>
                Feedback
				  <font size=7 color=white>
				  <div style="float:right">
				   <?php
              
                $sql="select * from feedback";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowecount=mysqli_num_rows($result);
                }
                echo"$rowecount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
			
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5" style="margin-left:80px;width:380px;height:150px;">
                <a href="deliverypartner.php"><div class="tm-bg-gray tm-video-details" style=
				"background: #787881	">
                <br>
              <font size=6 color=white>
              Delivery Partner
              <font size=7 color=white>
             <div style="float:right">
                <?php
               
                $sql="select * from deliverypartner";
                if($result=mysqli_query($conn,$sql))
                {
                    $rowacount=mysqli_num_rows($result);
                }
                echo"$rowacount";

                ?>
                </div>
                </font>
                </font>
                </div></a>
               
            </div>
            </div>
			
			
                <a href="logout.php">
				<font size=5 color=white>
				<center><button> LOGOUT</button></center>
				</font>
				</a><br>
			</div>
			</div>
   
 
<?php
	include("myfooter.php");
	}
?>
 </body>
</html>
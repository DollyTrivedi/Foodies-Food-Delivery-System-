<?php

include ("connection.php");
include ("header.php");

	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
		if(isset($_GET['delete']))
		{
		$del="delete from deliverypartner where deliverypartner_id=".$_GET['delete'];
		$rs=mysqli_query($conn,$del);
		}
?>
<!DOCTYPE html>
<html>
<body class="sub_page" background="images\bg4.png">
  
 
 <style>
 
  a{
	 color: white; 
 }
 
 .abc{
	 text-align: center;
	 font-size: 25px; 
	 background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
 }
  .table2{
	 text-align: center;
	 font-size: 18px; 
	 
 }
 
  .child1{
	
	 display: inline-block;
	 vertical-align: middle;
	 width: 18.55%;
	 height: 80%;
	 position: absolute;
	background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
   font-family: "Roboto", sans-serif;
 }
 .child2{
	 display: inline-block;
	 vertical-align: middle;
	 width: 74%;
	 margin-left: 20%;
 }
 .delete{
	 color: blue;
 }
 .add{
	 style=border-left: none; 
	 border-right: none; 
	 border-bottom: none;
	  background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
	background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
	 
	 }
	 .footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: fixed;
	width: 100%;
	bottom: 0;
	margin: 0px;
	
}
 </style>
<div class='parent' width=100%>	
 <div class='child1'> 
   <table width=100% height=80% bgcolor=#0077FFF class=abc>
 <tr>
  <td>
  <a href="home.php">Home</a>
  </td>
  </tr>
  
   <tr>
  <td>
  <a href="userdetails.php">Userdetails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="restaurents.php">Restaurants</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="category.php">Category<a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="menu.php">Menu</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="products.php">Products Deatails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="order.php">Order Details</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="feedback.php">Feedback Detils</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="deliverypartner.php">Delivery Partner
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="logout.php">Logout</a>
  </td>
  </tr>
  </table>
  </div>
  
  <div class='child2'>
  
  <h2 align=center><b>Delivery Partner Details</b></h2><br>
  <?php
  $result=mysqli_query($conn,"select * from deliverypartner");
  ?>
  <form method="post">
  <table align=center width=80% border=1px style="margin-bottom: 270px" class=table2>
	<tr>
		<td>
		<b>ID</b>
		</td>
		
		<td>
		<b>Name</b>
		</td>
		
		
		<td>
		<b>Contact</b>
		</td>
		
		<td>
		<b>E-mail</b>
		</td>
		
		<td>
		<b>Edit</b>
		</td>
						
		<td>
		<b>Delete</b>
		</td>
	</tr>
	
	<?php
	
	while($row=mysqli_fetch_array($result))
	{?>
		<tr>
		<td><?php echo $row[0];?></td>
		<td><?php echo $row[1];?></td>
		<td><?php echo $row[2];?></td>
		<td><?php echo $row[3];?></td>
		
		<td><a class=delete href="edit_deliverypartner.php?edit=<?php echo $row[0]; ?>">Edit</a></td>
		<td><a class=delete href="deliverypartner.php?delete=<?php echo $row[0]; ?>">Delete</a></td>
	</tr>
		
	<?php	
	}
	
	?>
	<tr class=add>
		<td colspan=36>
			<center><a href="add_deliverypartner.php"><u>Add new</u></a></center>
		</td>
	</tr>

  
 </table>
 </form>
  </div>
  
</div>
 
 <?php
	}
	//include("myfooter.php");
?>
<div class=footer style="border: 2px solid">
<center>

 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 
 </center>

</div>
 </body>
</html>
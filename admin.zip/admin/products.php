<?php

include ("connection.php");
include ("header.php");

	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
		if(isset($_GET['delete']))
		{
		$del="delete from food where Food_id=".$_GET['delete'];
		$rs=mysqli_query($conn,$del);
		}
?>
<!DOCTYPE html>
<html>

<body class="sub_page" background="images\bg4.png">

 <style>
 
  a{
	 color: white; 
 }
 
 .abc{
	 text-align: center;
	 font-size: 25px; 
	 background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
 }
  .table2{
	 text-align: center;
	 font-size: 18px; 
	 
 }
 
  .child1{
	
	 display: inline-block;
	 vertical-align: middle;
	 width: 18.55%;
	 height: 80%;
	 position: absolute;
	background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
   font-family: "Roboto", sans-serif;
 }
 .child2{
	 display: inline-block;
	 vertical-align: middle;
	 width: 74%;
	 margin-left: 20%;
 }
 .delete{
	 color: blue;
 }
 .add{
	 border-left: none;
	 border-right: none;
	 border-bottom: none;
	  background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
	 
 }
 
.footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: relative;
	width: 100%;
	bottom: 0;
	margin: 0px;
	
}
 
 </style>
<div class='parent' width=100%>	
 <div class='child1'> 
  <table width=100% height=230% bgcolor=#0077FFF class=abc>
 <tr>
  <td>
  <a href="home.php">Home</a>
  </td>
  </tr>
  
   <tr>
  <td>
  <a href="userdetails.php">Userdetails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="restaurents.php">Restaurants</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="category.php">Category<a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="menu.php">Menu</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="products.php">Products Deatails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="order.php">Order Details</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="feedback.php">Feedback Detils</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="deliverypartner.php">Delivery Partner
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="logout.php">Logout</a>
  </td>
  </tr>
  </table>
  </div>
  
  <div class='child2'>
  <h2 align=center><b>Product Details</b></h2><br>
   <?php
  $result=mysqli_query($conn,"select * from food");
  ?>
  <form method="post">
  <table align=center width=90% border=1px style="margin-bottom: 80px;" class=table2>
	
	<tr>
		<td width=60px>
		<b>ID</b>
		</td>
		
		<td>
		<b>Product Name</b>
		</td>
		
		<td>
		<b>Price</b>
		</td>
		
		<td>
		<b>Product Image</b>
		</td>
	
		<td>
		<b>Menu</b>
		</td>
		
		
		<td width=60px>
		<b>Edit</b>
		</td>
		
		<td>
		<b>Delete</b>
		</td>
	</tr>
	<?php
	
	while($row=mysqli_fetch_array($result))
	{?>
	<tr>
		<td><?php echo $row[0];?></td>
		<td><?php echo $row[1];?></td>
		<td><?php echo $row[2];?></td>
		<td> <img src="../images/<?php echo $row[3]; ?>" alt="Img" width="40"></td>
		<td><?php echo $row[4];?></td>
				
		<td><a class=delete href="edit_product.php?edit=<?php echo $row[0]; ?>" >Edit</a></td>
		<td><a class=delete href="products.php?delete=<?php echo $row[0]; ?>">Delete</a></td>
		<?php	
	}
	
	?>
	</tr>
	<tr class=add>
		<td colspan=7>
			<center><a href="add_product.php"><u>Add new</u></a></center>
		</td>
	</tr>
  </table>
  </form>
 

  </div>
  
</div>
 
<?php
	}
	
	//include("myfooter.php");
?>
<div class=footer style="border: 2px solid">
<center>

 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 
 </center>

</div>
 </body>
</html>
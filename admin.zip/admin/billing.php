<?php

include ("connection.php");
include ("header.php");

	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
		$rs=$_GET['ord'];
		$result=mysqli_query($conn,"select * from payment where Order_id='".$_GET['ord']."'");	
		$row=mysqli_fetch_array($result);
			
		$user=mysqli_query($conn,"select * from user where User_name='".$row[6]."'");
		$user1=mysqli_fetch_row($user);
		$dp=mysqli_query($conn,"select * from deliverypartner");
		$dp1=mysqli_fetch_row($dp);
		
		if(isset($_GET['ord']))
			{
			$rs=$_GET['ord'];
			
			$result=mysqli_query($conn,"select * from payment where Order_id='".$_GET['ord']."'");	
			$row=mysqli_fetch_array($result);	
			
			$bl=mysqli_query($conn,"select * from bill where Payment_id='".$row[0]."'");
			$bl1=mysqli_fetch_array($bl);
?>
<!DOCTYPE html>
<html>
<body class="sub_page" background="images\bg4.png">
 
<style>
th,td{
	padding: 30px;
}
.footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: relative;
	width: 100%;
	
	bottom: 0%;
	
}
</style>

<h2 align=center><b>Billing Details</b></h2><br>
<table align="center" border=2px width=50% style="margin-bottom: 0px;">
	
	<tr align=center>
		<td colspan=4 align=center>
		<h3><b>FOODIES</b></h3>
		</td>
	</tr>
	
	<tr>
		<td align=left> 
		<font size=4px>Name:<?php echo $user1[1]?><br>
		Contact: <?php echo $user1[4]?><br>
		Address: <?php echo $user1[6]?></font>
		</td>
		<td style="border-left-style: hidden;"></td>
		<td align=left>
		<font size=4px>
		Date: <?php echo $bl1[1]?><br>
		Delivery partner: <?php echo $dp1[1]?><br>
		Contact: <?php echo $dp1[2]?></font> 
		</td>
		<td style="border-left-style: hidden;"></td>
		
	</tr>
	<tr>
		<td colspan=2 align=center>
		<font size=4px><b>Item name 
		</td>
		
		<td align=center>
		<font size=4px><b>Quantity 
		</td>
		
		<td align=center>
		<font size=4px><b>price
		</td>
		
		
	</tr>
	<tr>
		<td colspan=2>
		<?php echo $row[2]?>
		</td>
		
		<td align=center>
		<?php echo $row[3]?>
		</td>
		
		<td align=center>
		<?php echo $row[4]?>
		</td>
	</tr>
	
	<tr>
		<td colspan=3 align=right>
		<font size=4px><b>Grand Total
		</td>
		
		<td align=center>
		<?php echo $bl1[2]?>
		</td>
	</tr>
	
	<tr>
		<td colspan=4 align=center>
		<font size=4px color=red>Paymeny will be accepted only by Cash on Delivery...!<br><br>
		<a href="order.php"><button>Done</button></a>
		</td>
		
	</tr>
</table><br>



  <!-- footer section -->
   <script>
    function openNav() {
      document.getElementById("myNav").classList.toggle("menu_width");
      document
        .querySelector(".custom_menu-btn")
        .classList.toggle("menu_btn-style");
    }
  </script>
  <?php
	}
	}
//include("myfooter.php");
  ?>
<div class=footer style="border: 2px solid;">
<center>


 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 </center>

</div>
 
</body>

</html>
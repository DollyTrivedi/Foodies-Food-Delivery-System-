<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   	<title>FOODIES</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
   
    <link rel="stylesheet" href="css/templatemo-style.css">
	<link rel="stylesheet" href="css/admin.css">
	
	
	<style>
	.acolor:link{
color:black;
}
.acolor:visited{
color:black;
}
.acolor:active{
color:black;
}

.td {
  
  text-align: left;
  padding: 8px;
  border: 2px solid;
  font-size:20px;
 
  
}
.th {
  
  text-align: left;
  padding: 8px;
  border: 2px solid;
  font-size:20px;
  background-color:lightgreen;
  
}
</style>

</head>
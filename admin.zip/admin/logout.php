<?php
include ("connection.php");
session_start();

if(isset($_SESSION['sid']))
{
	unset($_SESSION['sid']);
	//session_destroy();
	//$_SESSION['sid']="";
	header("Location:index.php");
}
?>		
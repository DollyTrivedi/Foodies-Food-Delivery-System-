<?php
$conn = mysqli_connect("localhost", "root", "", "foodies");
if (!$conn) {
    echo "Connection failed!";
}
?>
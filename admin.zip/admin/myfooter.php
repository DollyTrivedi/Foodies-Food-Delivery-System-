<html>
<title>Footer</title>
<style>

.footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: relative;
	width: 100%;
	
	bottom: 0%;
	
}
body{
	margin: 0px;
}

</style>
<body>



<div class=footer style="border: 2px solid;">
<center>


 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 </center>

</div>

  <!-- footer section -->
   <script>
    function openNav() {
      document.getElementById("myNav").classList.toggle("menu_width");
      document
        .querySelector(".custom_menu-btn")
        .classList.toggle("menu_btn-style");
    }
  </script>
</body>
</html>
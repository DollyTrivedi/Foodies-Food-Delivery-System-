
<!DOCTYPE html>
<html>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>FOODIES</title> 
  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700|Raleway:400,700&display=swap"
    rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page" background="images\bg4.png">
  <div class="hero_area">
     <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid" >
        <nav class="navbar navbar-expand-lg custom_nav-container" >
          <a class="navbar-brand" href="#">
            <img src="images/foodlogo.png" alt="" height=80px width=800px/>
            <span>
             <h1> FOODIES <h1>
            </span>
          </a>
		  	
	   </div>
	   <div class="navbar-collapse" id="">
            <div class="custom_menu-btn">
			<?php 
			session_start();
			include("connection.php");
			if(isset($_SESSION['sid']))
			  {
				  
			$query=mysqli_query($conn,"select * from admin where Admin_id='".$_SESSION['sid']."'");
			$qu=mysqli_fetch_row($query);
			?>
				 <center><b><font size=5px color=blue>Welcome <?php echo $qu[1]; ?> !</font> </b><br></center>  
			  <?php } ?>
            </div>
			
        </nav> 
		
      </div>
	   
    </header>
    <!-- end header section -->
  </div>
  </body>
  </html>
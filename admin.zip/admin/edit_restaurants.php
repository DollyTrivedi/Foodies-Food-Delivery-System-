<?php

include ("connection.php");
include ("header.php");
		
	if(!isset($_SESSION['sid']))
	{
		?> <script>
		alert("Please Login first.");
		window.location.replace('index.php');
		
		</script><?php	
	}
	else
	{
	$no=$_GET['edit'];
	$sql="select * from restaurant where Restaurant_id='$no'";
	$result=mysqli_query($conn,$sql);
	
	
	if(isset($_POST["update"]))
	{
		
	$filename = $_FILES["image1"]["name"];
    if(empty($filename))
	{
	if(empty($_POST["resturantname"]) && $_POST["resturantadd"] && $_POST["contact"])
		{
			header("location: edit_menu.php");
		}	
		
	$sql="update restaurant set Restaurant_name='".$_POST["resturantname"]."', Address='".$_POST["resturantadd"]."',Contact='".$_POST["contact"]."' where Restaurant_id='".$_GET['edit']."'";
	if(mysqli_query($conn,$sql))
		echo "<script>window.location='restaurents.php';</script>";
	else
		echo "Not Updated";

	}
	else
	{
		$filename = $_FILES["image1"]["name"];
		$tempname = $_FILES["image1"]["tmp_name"];
		$folder = "../images/" . $filename;
	
		if(empty($_POST["resturantname"]) && empty($_POST["resturantadd"]) && empty($_POST["contact"]) && empty($filename))
		{
			header("location: edit_restaurants.php");
		}	
		
	$sql="update restaurant set Restaurant_name='".$_POST["resturantname"]."', Address='".$_POST["resturantadd"]."',Contact='".$_POST["contact"]."', Restaurant_image='".$filename."' where Restaurant_id='".$_GET['edit']."'";
	if(mysqli_query($conn,$sql))
		echo "<script>window.location='restaurents.php';</script>";
	else
		echo "Not Updated";
	}
	}
	while($row=mysqli_fetch_array($result,MYSQLI_BOTH))
	{
	
?>
<!DOCTYPE html>
<html>

<body class="sub_page" background="images\bg4.png">
  
 
 <style>
 
  a{
	 color: white; 
 }
 
 .abc{
	 text-align: center;
	 font-size: 25px; 
	 background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
 }
  .table2{
	 text-align: left;
	 font-size: 18px; 
	 
 }
 
  .child1{
	
	 display: inline-block;
	 vertical-align: middle;
	 width: 18.55%;
	 height: 80%;
	 position: absolute;
	background: -webkit-gradient(linear, left top, right top, from(#51b5ef), to(#436bf1));
  background: linear-gradient(to right, #51b5ef, #436bf1);
   color: #fefeff;
   font-family: "Roboto", sans-serif;
 }
 .child2{
	 display: inline-block;
	 vertical-align: middle;
	 width: 74%;
	 margin-left: 20%;
 }
 .delete{
	 color: blue;
 }
 .footer{
	background: black;
	color: white;
	text-size: 10px;
	padding: 20px;
	position: relative;
	width: 100%;
	top: 17px;
	bottom: 0;
	margin: 0px;
	
}

 </style>
<div class='parent' width=100%>	
 <div class='child1'> 
   <table width=100% height=90% bgcolor=#0077FFF class=abc>
 <tr>
  <td>
  <a href="home.php">Home</a>
  </td>
  </tr>
  
   <tr>
  <td>
  <a href="userdetails.php">Userdetails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="restaurents.php">Restaurants</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="category.php">Category<a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="menu.php">Menu</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="products.php">Products Deatails</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="order.php">Order Details</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="feedback.php">Feedback Detils</a>
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="deliverypartner.php">Delivery Partner
  </td>
  </tr>
  
    <tr>
  <td>
  <a href="logout.php">Logout</a>
  </td>
  </tr>
  </table>
  </div>
  
  <div class='child2'>
  
  <form method="post" enctype="multipart/form-data">
  <table align=center width=80% style="margin-bottom: 1px" class=table2>

 <tr>
	<td colspan=2>
	<h2><b>Edit  Resturant Details</b></h2><br>
	</td>
  </tr>
	<tr>
		<td style="font-size: 23px">
		<label>Restaurant name </label>
		</td>
		<td style="font-size: 23px">
		<input type=text name="resturantname" value='<?php echo $row[1]; ?>'>
		</td>
	</tr>
	
	<tr>
		<td style="font-size: 23px">
		<label>Restaurant Address </label>
		</td>
		<td style="font-size: 23px">
		<textarea name="resturantadd" cols=24 value=''><?php echo $row[2]; ?></textarea>
		</td>
	</tr>
	
	<tr>
		<td style="font-size: 23px">
		<label>Restaurant Contact </label>
		</td>
		<td style="font-size: 23px">
		<input type=text name="contact" value='<?php echo $row[3]; ?>'>
		</td>
	</tr>
	
	
	<tr>
		<td style="font-size: 23px">
		<label>Restaurant Image </label>
		</td>
		<td style="font-size: 23px">
		<input type="image" src="../images/<?php echo $row[4]; ?>" height=40% width=40%><br>
		<input type="file" name="image1">
		</td>
	</tr>

	<tr>
		<td colspan=2 style="font-size: 23px" >
		<br><input type="submit" class=abc name="update" value="Update">
		</td>
	</tr>
	
  </table>
  </form><br>
  

  </div>
  
</div>
 
  
<?php
	}
	}
	//include("myfooter.php");
?>
<div class=footer style="border: 2px solid">
<center>

 <h4>&copy; 2023 FOODIES.All rights reserved <br>
 Contact: foodies@gmail.com</h4>
 
 </center>
</div>
 </body>
</html>